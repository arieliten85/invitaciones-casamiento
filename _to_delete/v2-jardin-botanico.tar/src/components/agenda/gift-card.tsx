"use client";

import { useState } from "react";
import { glyphs } from "./block";

type Props = { bank: string; holder: string; alias: string };

function Glyph({ d, className = "h-4 w-4" }: { d: string; className?: string }) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      className={className}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d={d} />
    </svg>
  );
}

/** Tarjeta de regalos: alias con botón de copiar, como en el ejemplo. */
export function GiftCard({ bank, holder, alias }: Props) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(alias);
    } catch {
      const area = document.createElement("textarea");
      area.value = alias;
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.append(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="reveal-lg bg-card border-line mx-auto max-w-sm rounded-[1.75rem] border p-5 text-left shadow-[0_24px_50px_-32px_rgb(54_65_47/0.45)]">
      <div className="flex items-center gap-3">
        <span className="bg-leaf flex h-11 w-11 items-center justify-center rounded-xl text-white">
          <Glyph d={glyphs.gift} className="h-5 w-5" />
        </span>
        <div>
          <p className="text-leaf-deep text-[0.62rem] tracking-[0.25em] uppercase">Transferencia</p>
          <p className="text-moss font-medium">{bank}</p>
        </div>
      </div>

      <div className="bg-paper mt-4 flex items-center justify-between gap-3 rounded-2xl px-4 py-3">
        <div className="min-w-0">
          <p className="text-moss-soft text-[0.62rem] tracking-[0.25em] uppercase">Alias</p>
          <p className="text-moss truncate font-mono text-[0.95rem] select-all">{alias}</p>
        </div>
        <button
          type="button"
          onClick={copy}
          aria-label={copied ? "Alias copiado" : "Copiar alias"}
          className="bg-leaf hover:bg-leaf-deep flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white transition"
        >
          <Glyph d={copied ? glyphs.check : glyphs.copy} />
        </button>
      </div>

      <div className="bg-paper mt-2 rounded-2xl px-4 py-3">
        <p className="text-moss-soft text-[0.62rem] tracking-[0.25em] uppercase">Titular</p>
        <p className="text-moss text-[0.95rem]">{holder}</p>
      </div>
      <span className="sr-only" role="status">
        {copied ? "Alias copiado" : ""}
      </span>
    </div>
  );
}

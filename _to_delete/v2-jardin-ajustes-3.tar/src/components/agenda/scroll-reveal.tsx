"use client";

import { useEffect } from "react";

const SELECTOR = ".reveal, .reveal-lg, .reveal-zoom, .reveal-stagger > *, .reveal-grid > *";

/**
 * Efecto de aparición al hacer scroll para navegadores sin «scroll-driven animations»
 * (Firefox, Safari). En Chrome/Edge lo hace el CSS solo y este componente no hace nada.
 * Si no hay JavaScript o la persona pidió menos movimiento, todo queda visible.
 */
export function ScrollReveal() {
  useEffect(() => {
    if (CSS.supports("animation-timeline: view()")) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const root = document.documentElement;
    const items = Array.from(document.querySelectorAll<HTMLElement>(SELECTOR));
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          e.target.classList.add("is-in");
          io.unobserve(e.target);
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
    );
    root.dataset.reveal = "io";
    items.forEach((el) => {
      // Los hijos de un grupo entran escalonados.
      const group = el.parentElement?.matches(".reveal-stagger, .reveal-grid");
      if (group)
        el.style.transitionDelay = `${(Array.from(el.parentElement!.children).indexOf(el) % 3) * 110}ms`;
      io.observe(el);
    });
    return () => {
      io.disconnect();
      delete root.dataset.reveal;
      items.forEach((el) => el.classList.remove("is-in"));
    };
  }, []);

  return null;
}
